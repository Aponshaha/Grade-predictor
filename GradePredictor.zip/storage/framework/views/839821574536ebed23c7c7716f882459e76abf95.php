<form action="/calc" method="post" >
    <?php echo e(csrf_field()); ?>

    <input placeholder="A" value="<?php echo e($a); ?>" name="a" />
    <select name="action">
        <option <?php if($action == '+'): ?> selected="selected" <?php endif; ?>>+</option>
        <option <?php if($action == '-'): ?> selected="selected" <?php endif; ?>>-</option>
        <option <?php if($action == '*'): ?> selected="selected" <?php endif; ?>>*</option>
        <option <?php if($action == '/'): ?> selected="selected" <?php endif; ?>>/</option>
    </select>
    <input placeholder="B" value="<?php echo e($b); ?>" name="b" />
    <input placeholder="C" value="<?php echo e($c); ?>" name="c" />
    <input placeholder="D" value="<?php echo e($d); ?>" name="d" />
    <?php if(isset($result)): ?>
        <strong>= <?php echo e($result); ?></strong>
    <?php endif; ?>
    <button>Execute</button>
</form>